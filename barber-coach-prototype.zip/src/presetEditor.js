export function initPresetEditor(defaultPreset, callbacks){
  const el = id=>document.getElementById(id);
  const editor = el('preset-editor');
  const nameInput = el('editor-name');
  const totalMin = el('editor-total-min');
  const list = el('editor-checkpoints');
  const newLabel = el('new-label');
  const newMin = el('new-min');
  const newSec = el('new-sec');

  // helper: convert checkpoints with offsets into durations
  function offsetsToDurations(checkpoints, totalSeconds){
    const out = [];
    let prev = 0;
    for(const cp of (checkpoints||[])){
      const offset = cp.offset || 0;
      const dur = Math.max(0, offset - prev);
      out.push({ id: cp.id, label: cp.label, duration: dur });
      prev = offset;
    }
    // if there is a trailing duration (totalSeconds - last offset) and no extra cp, ignore
    return out;
  }

  // working model stores per-checkpoint durations (seconds) for editing
  let working = {
    id: defaultPreset.id,
    name: defaultPreset.name,
    totalSeconds: defaultPreset.totalSeconds,
    checkpoints: offsetsToDurations(defaultPreset.checkpoints, defaultPreset.totalSeconds)
  };

  function render(){
    nameInput.value = working.name || '';
    totalMin.value = Math.ceil((working.totalSeconds||0)/60) || 20;
    list.innerHTML = '';
    working.checkpoints.forEach((cp, idx)=>{
      const li = document.createElement('li');
      li.className = 'cp-row';
      const left = document.createElement('div');
      left.className = 'cp-left';
      left.textContent = `${Math.floor(cp.duration/60)}:${String(cp.duration%60).padStart(2,'0')} — ${cp.label}`;
      const controls = document.createElement('div');
      controls.className = 'cp-controls';
      const up = document.createElement('button'); up.textContent='↑';
      const down = document.createElement('button'); down.textContent='↓';
      const test = document.createElement('button'); test.textContent='test';
      const del = document.createElement('button'); del.textContent='✕';
      up.addEventListener('click', ()=>{ if(idx>0){ working.checkpoints.splice(idx-1,0,working.checkpoints.splice(idx,1)[0]); render(); } });
      down.addEventListener('click', ()=>{ if(idx<working.checkpoints.length-1){ working.checkpoints.splice(idx+1,0,working.checkpoints.splice(idx,1)[0]); render(); } });
      del.addEventListener('click', ()=>{ working.checkpoints.splice(idx,1); render(); });
      test.addEventListener('click', ()=>{ if(callbacks && callbacks.onTest) callbacks.onTest({ label: cp.label, offset: cp.offset || 0 }); });
      controls.appendChild(up); controls.appendChild(down); controls.appendChild(test); controls.appendChild(del);
      li.appendChild(left); li.appendChild(controls);
      list.appendChild(li);
    });
  }

  el('edit-preset').addEventListener('click', ()=>{
    // rebuild working from defaultPreset
    working = {
      id: defaultPreset.id,
      name: defaultPreset.name,
      totalSeconds: defaultPreset.totalSeconds,
      checkpoints: offsetsToDurations(defaultPreset.checkpoints, defaultPreset.totalSeconds)
    };
    editor.classList.remove('hidden'); render();
  });

  el('cancel-preset').addEventListener('click', ()=>{ editor.classList.add('hidden'); });

  el('add-cp').addEventListener('click', ()=>{
    const label = newLabel.value.trim();
    const m = parseInt(newMin.value||0,10);
    const s = parseInt(newSec.value||0,10);
    if(!label) return;
    const duration = (m*60)+(s||0);
    working.checkpoints.push({ id: `cp-${Date.now()}`, label, duration });
    newLabel.value=''; newMin.value=''; newSec.value=''; render();
  });

  el('save-preset').addEventListener('click', ()=>{
    working.name = nameInput.value || 'Preset';
    working.totalSeconds = (parseInt(totalMin.value||20,10)||20)*60;
    // convert durations into offsets (cumulative)
    let cum = 0;
    const cpWithOffsets = working.checkpoints.map(cp=>{
      const offset = cum;
      const out = { id: cp.id, label: cp.label, offset };
      cum += (cp.duration||0);
      return out;
    });
    // ensure totalSeconds at least sum
    if (working.totalSeconds < cum) working.totalSeconds = cum;
    const presetOut = { id: working.id || `preset-${Date.now()}`, name: working.name, totalSeconds: working.totalSeconds, checkpoints: cpWithOffsets };
    editor.classList.add('hidden');
    if(callbacks && callbacks.onSave) callbacks.onSave(presetOut);
  });

  // expose a method to programmatically open the editor with a preset
  return {
    openWith(p){ working = {
      id: p.id,
      name: p.name,
      totalSeconds: p.totalSeconds,
      checkpoints: offsetsToDurations(p.checkpoints, p.totalSeconds)
    }; editor.classList.remove('hidden'); render(); }
  };
}
